import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import HookForm from './components/HookForm';

function App() {
  return (
    <div className="App">
      <HookForm/>
      
    </div>
  );
}

export default App;
